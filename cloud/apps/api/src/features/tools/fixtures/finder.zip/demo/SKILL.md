---
name: demo
description: Demo skill
---
Follow these steps.
